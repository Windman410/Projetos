-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 25-Nov-2017 às 07:24
-- Versão do servidor: 10.1.28-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sistemappc`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_atas`
--

CREATE TABLE `tb_atas` (
  `id_atas` int(8) NOT NULL,
  `data` int(11) NOT NULL,
  `local` varchar(255) NOT NULL,
  `participantes` varchar(255) NOT NULL,
  `deliberacoes` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_atas`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_bibliografia`
--

CREATE TABLE `tb_bibliografia` (
  `id_bibliografia` int(8) NOT NULL,
  `cursos` varchar(100) NOT NULL,
  `disciplinas` varchar(100) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `autor` varchar(255) NOT NULL,
  `ano` int(15) NOT NULL,
  `isbn` varchar(255) NOT NULL,
  `editora` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_bibliografia`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_cronograma`
--

CREATE TABLE `tb_cronograma` (
  `id_cronograma` int(8) NOT NULL,
  `aula` int(8) NOT NULL,
  `conteudo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_cronograma`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_curso`
--

CREATE TABLE `tb_curso` (
  `id_curso` int(8) NOT NULL,
  `tipo` varchar(100) NOT NULL,
  `modalidade` varchar(100) NOT NULL,
  `denominacao` varchar(100) NOT NULL,
  `habilitacao` varchar(100) NOT NULL,
  `localOferta` varchar(100) NOT NULL,
  `matutino` tinyint(1) NOT NULL,
  `vespertino` tinyint(1) NOT NULL,
  `noturno` tinyint(1) NOT NULL,
  `vagasTurno` int(8) NOT NULL,
  `cargaHoraria` int(8) NOT NULL,
  `regimeLetivo` varchar(100) NOT NULL,
  `periodo` varchar(100) NOT NULL,
  `nomeProfessor` varchar(100) NOT NULL,
  `cpf` bigint(16) NOT NULL,
  `titulacao` varchar(100) NOT NULL,
  `tempoDedicacao` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_curso`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_disciplinas`
--

CREATE TABLE `tb_disciplinas` (
  `id_disciplinas` int(8) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `cod` int(11) NOT NULL,
  `descricao` varchar(1000) NOT NULL,
  `semestre` int(8) NOT NULL,
  `cargaHoraria` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_disciplinas`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_planoensino`
--

CREATE TABLE `tb_planoensino` (
  `id_plano` int(8) NOT NULL,
  `curso` varchar(100) NOT NULL,
  `ano` int(15) NOT NULL,
  `semestre` int(8) NOT NULL,
  `disciplina` varchar(100) NOT NULL,
  `cargaHoraria` int(8) NOT NULL,
  `periodoCurso` varchar(100) NOT NULL,
  `professor` varchar(100) NOT NULL,
  `ementa` varchar(1000) NOT NULL,
  `competenciasHabilidades` varchar(1000) NOT NULL,
  `metodologiaEnsino` varchar(1000) NOT NULL,
  `avaliacao` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_planoensino`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_ppc`
--

CREATE TABLE `tb_ppc` (
  `id_ppc` int(8) NOT NULL,
  `cursoPPC` varchar(1000) NOT NULL,
  `perfilCurso` varchar(1000) NOT NULL,
  `perfilEgresso` varchar(1000) NOT NULL,
  `formaAcesso` varchar(1000) NOT NULL,
  `representacao` varchar(1000) NOT NULL,
  `avaliacaoProcesso` varchar(1000) NOT NULL,
  `avaliacaoProjeto` varchar(1000) NOT NULL,
  `horasTCC` int(8) NOT NULL,
  `horasEstagio` int(8) NOT NULL,
  `politicaDeAtendimento` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_ppc`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_professor`
--

CREATE TABLE `tb_professor` (
  `id_professor` int(8) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `cpf` bigint(16) NOT NULL,
  `maiorTitulacao` varchar(100) NOT NULL,
  `areaFormacao` varchar(100) NOT NULL,
  `curriculo` varchar(100) NOT NULL,
  `dataAtualizacao` varchar(100) NOT NULL,
  `matricula` int(8) NOT NULL,
  `dataAdimissao` varchar(100) NOT NULL,
  `horasNDE` int(8) NOT NULL,
  `horasOrientacaoTCC` int(8) NOT NULL,
  `horasCordenacaoCurso` int(8) NOT NULL,
  `horasCordenacaoOutrosCurso` int(8) NOT NULL,
  `horasPesquisa` int(8) NOT NULL,
  `horasExtraClasseCurso` int(8) NOT NULL,
  `horasExtraClasseOutrosCurso` int(8) NOT NULL,
  `horasCurso` int(8) NOT NULL,
  `horasOutrosCurso` int(8) NOT NULL,
  `disciplinaCurso` int(8) NOT NULL,
  `cargaHorariaCurso` int(8) NOT NULL,
  `disciplinaOutrosCurso` int(8) NOT NULL,
  `cargaHorariaOutrosCurso` int(8) NOT NULL,
  `membroNDE` tinyint(1) NOT NULL,
  `membroColegiado` tinyint(1) NOT NULL,
  `experienciaPedagogia` tinyint(1) NOT NULL,
  `tempoVinculoCurso` varchar(100) NOT NULL,
  `experienciaMagisterioSuperior` varchar(100) NOT NULL,
  `experienciaCursoDistancia` varchar(100) NOT NULL,
  `experienciaProfissional` varchar(100) NOT NULL,
  `participacaoEventos` int(8) NOT NULL,
  `artigoCientificoArea` int(8) NOT NULL,
  `artigoCientificoOutrasArea` int(8) NOT NULL,
  `livrosCapitulosArea` int(8) NOT NULL,
  `livrosCapitulosOutrasArea` int(8) NOT NULL,
  `trabalhoAnaisArea` int(8) NOT NULL,
  `trabalhoAnaisOutrasArea` int(8) NOT NULL,
  `propriedadeIntelectualArea` int(8) NOT NULL,
  `propriedadeIntelectualOutrasArea` int(8) NOT NULL,
  `traducoesPublicadas` int(8) NOT NULL,
  `projetoTecnicaArtisticaCultural` int(8) NOT NULL,
  `producoesDidaticoPedagogico` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_professor`
--


--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_atas`
--
ALTER TABLE `tb_atas`
  ADD PRIMARY KEY (`id_atas`);

--
-- Indexes for table `tb_bibliografia`
--
ALTER TABLE `tb_bibliografia`
  ADD PRIMARY KEY (`id_bibliografia`);

--
-- Indexes for table `tb_cronograma`
--
ALTER TABLE `tb_cronograma`
  ADD PRIMARY KEY (`id_cronograma`);

--
-- Indexes for table `tb_curso`
--
ALTER TABLE `tb_curso`
  ADD PRIMARY KEY (`id_curso`);

--
-- Indexes for table `tb_disciplinas`
--
ALTER TABLE `tb_disciplinas`
  ADD PRIMARY KEY (`id_disciplinas`);

--
-- Indexes for table `tb_planoensino`
--
ALTER TABLE `tb_planoensino`
  ADD PRIMARY KEY (`id_plano`);

--
-- Indexes for table `tb_ppc`
--
ALTER TABLE `tb_ppc`
  ADD PRIMARY KEY (`id_ppc`);

--
-- Indexes for table `tb_professor`
--
ALTER TABLE `tb_professor`
  ADD PRIMARY KEY (`id_professor`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_atas`
--
ALTER TABLE `tb_atas`
  MODIFY `id_atas` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tb_bibliografia`
--
ALTER TABLE `tb_bibliografia`
  MODIFY `id_bibliografia` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tb_cronograma`
--
ALTER TABLE `tb_cronograma`
  MODIFY `id_cronograma` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tb_curso`
--
ALTER TABLE `tb_curso`
  MODIFY `id_curso` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tb_disciplinas`
--
ALTER TABLE `tb_disciplinas`
  MODIFY `id_disciplinas` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tb_planoensino`
--
ALTER TABLE `tb_planoensino`
  MODIFY `id_plano` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tb_ppc`
--
ALTER TABLE `tb_ppc`
  MODIFY `id_ppc` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tb_professor`
--
ALTER TABLE `tb_professor`
  MODIFY `id_professor` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
